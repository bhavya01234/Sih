<div>
    <h2 align="center">Pay now with Paypal:</h2>
    <p style="text-align: center;"><img src="paytm.jpg" width="300" height="150"></p>
</div>