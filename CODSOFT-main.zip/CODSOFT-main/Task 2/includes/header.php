<div class="header_wrapper">
    <a href="index.php"><img id="logo" src="images/logo.jpg"></a>
    <img id="banner" src="images/banner.jpg">
</div>