<div id="footer">
    <h2 style="text-align: center; padding-top: 30px;">&copy Amogh Bansal 21803008</h2>
</div>